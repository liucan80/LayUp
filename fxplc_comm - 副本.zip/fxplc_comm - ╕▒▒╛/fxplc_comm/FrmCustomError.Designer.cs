﻿namespace fxplc_comm
{
    partial class FrmCustomError
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSaveErrorTable = new System.Windows.Forms.Button();
            this.dgvErrors = new System.Windows.Forms.DataGridView();
            this.ComponentName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.作用 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvErrors)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSaveErrorTable
            // 
            this.btnSaveErrorTable.Location = new System.Drawing.Point(392, 431);
            this.btnSaveErrorTable.Name = "btnSaveErrorTable";
            this.btnSaveErrorTable.Size = new System.Drawing.Size(75, 23);
            this.btnSaveErrorTable.TabIndex = 5;
            this.btnSaveErrorTable.Text = "保存";
            this.btnSaveErrorTable.UseVisualStyleBackColor = true;
            this.btnSaveErrorTable.Click += new System.EventHandler(this.btnSaveErrorTable_Click);
            // 
            // dgvErrors
            // 
            this.dgvErrors.AllowUserToAddRows = false;
            this.dgvErrors.AllowUserToDeleteRows = false;
            this.dgvErrors.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ComponentName,
            this.作用});
            this.dgvErrors.Location = new System.Drawing.Point(-1, 2);
            this.dgvErrors.MultiSelect = false;
            this.dgvErrors.Name = "dgvErrors";
            this.dgvErrors.RowTemplate.Height = 23;
            this.dgvErrors.Size = new System.Drawing.Size(468, 423);
            this.dgvErrors.TabIndex = 4;
            // 
            // ComponentName
            // 
            this.ComponentName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ComponentName.HeaderText = "软元件";
            this.ComponentName.Name = "ComponentName";
            this.ComponentName.ReadOnly = true;
            // 
            // 作用
            // 
            this.作用.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.作用.HeaderText = "错误描述";
            this.作用.Name = "作用";
            // 
            // FrmCustomError
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 460);
            this.Controls.Add(this.btnSaveErrorTable);
            this.Controls.Add(this.dgvErrors);
            this.Name = "FrmCustomError";
            this.Text = "报警自定义";
            this.Load += new System.EventHandler(this.FrmCustomError_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvErrors)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSaveErrorTable;
        private System.Windows.Forms.DataGridView dgvErrors;
        private System.Windows.Forms.DataGridViewTextBoxColumn ComponentName;
        private System.Windows.Forms.DataGridViewTextBoxColumn 作用;
    }
}