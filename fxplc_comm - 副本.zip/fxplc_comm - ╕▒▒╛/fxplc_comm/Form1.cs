﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace fxplc_comm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int data1;
        int output000, output001, output002, output003, output004, output005, output006, output007, output010, output011, output012, output013, output014, output015, output016, output017;
        int input000, input001, input002, input003, input004, input005, input006, input007, input010, input011, input012, input013, input014, input015, input016, input017, input024;
        int m8000;
        int d010,d011,d012;
        int stationNumber;
        bool connectionStatus = false;
        private void button1_Click(object sender, EventArgs e)
        {
            if (connectionStatus ==false)
            {
                
                if (int.TryParse(textBox2.Text,out stationNumber))
                {
               
                axActUtlType1.ActLogicalStationNumber = stationNumber;
                }
                else
                {
                    errorProvider1.SetError(this.textBox2, "站号输入错误");
                
                    return;
                }
               
                int iReturnCOde = axActUtlType1.Open();
                if (iReturnCOde == 0)
                {
                    toolStripStatusLabel2.Text = "PLC已连接";

                }
                else
                {
                    toolStripStatusLabel2.Text = "PLC连接失败";
                    return;
                }
                connectionStatus = true;
                int cpuType;
                string cpuName;
                int returnCode = axActUtlType1.GetCpuType(out cpuName, out cpuType);
                textBox1.Text = puName;
                timer1.Start();
                button28.Enabled = true;
                button1.Text = "断开";
            }
            else
            {
                int iReturnCOde= axActUtlType1.Close();
                button1.Text = "连接";
                if (iReturnCOde == 0)
                {
                    toolStripStatusLabel2.Text = "PLC已断开";
                    button28.Enabled = false;

                }
                connectionStatus = false;
            }
            
        }



        private void button2_Click(object sender, EventArgs e)
        {
            ///获取M8000继电器状态,切换PLC打开关闭状态。
            int data2;
            int tempCode=axActUtlType1.GetDevice("M8000",out data2);
            if (data2==0)
            {
                int tempReturnCode = axActUtlType1.SetCpuStatus(0);
            }
            else
            {
                int tempReturnCode = axActUtlType1.SetCpuStatus(1); 
            }
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           
            //int tempReturnCode = axActUtlType1.ReadDeviceBlock("y0", 2, out data1);
            //toolStripStatusLabel1.Text = data1.ToString();
            //string data2= Convert.ToString(data1,2).PadLeft(32,'0');
            //Char[] chars = data2.ToCharArray();
    //        int temp1 = (int)( chars[chars.Length - 9]-'0');
    //        if (temp1==1)
    //        {
    //            checkBox1.CheckState = CheckState.Checked;
    //        }
    //        else
    //{
    //            checkBox1.CheckState=CheckState.Unchecked;
    //}
           // toolStripStatusLabel2.Text = tempReturnCode.ToString();
            getSetStatus("x12", button13, out input012);
            getSetStatus("x13", button14, out input013);
            getSetStatus("x10", button16, out input010);
            getSetStatus("x11", button12, out input011);
            getSetStatus("x24", button15, out input024);
            getSetStatus("x003", button4, out input003);
            getSetStatus("x004", button5, out input004);
            getSetStatus("x005", button6, out input005);
            getSetStatus("y000", button17, out output000);
            getSetStatus("y001", button18, out output001);
            getSetStatus("y002", button19, out output002);
            getSetStatus("y004", button21, out output004);
            getSetStatus("y005", button22, out output005);
            getSetStatus("y007", button23, out output007);
            getSetStatus("y012", button27, out output012);
            getSetStatus("y010", button25, out output010);
            getSetStatus("y011", button24, out output011);
            //ovalShape3.BackColor = button22.BackColor;
            //ovalShape1.BackColor = button21.BackColor;
            //ovalShape2.BackColor = button27.BackColor;
            axActUtlType1.GetDevice("M8000", out m8000);
            if (m8000==0)
            {
                toolStripStatusLabel2.Text = "PLC已停止运行";
            }
            else if (m8000==1)
            {
                toolStripStatusLabel2.Text = "PLC正在运行";
            }


        }

      


     

        private void button28_Click(object sender, EventArgs e)
        {
            try
            {
                //axActUtlType1.SetDevice("D10",Convert.ToInt32( textBox3.Text));
                if (int.TryParse(textBox3.Text, out d010))
	                {
                        axActUtlType1.SetDevice("D010", d010);
                        toolStripStatusLabel1.Text = "D010写入成功";
	                }
                else
                {
                    errorProvider1.SetError(textBox3, "请输入正确格式");
                }
                if (int.TryParse(textBox4.Text, out d011))
                {
                    axActUtlType1.SetDevice("D011", d011);
                }
                if (int.TryParse(textBox5.Text, out d012))
                {
                    axActUtlType1.SetDevice("D012", d012);
                }  
               
                //axActUtlType1.SetDevice("D11", Convert.ToInt32(textBox4.Text));
                //axActUtlType1.SetDevice("D12", Convert.ToInt32(textBox5.Text));
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        private int getSetStatus(string name, Button buttonName,out int tempVar)
        {
            int tempInt;
            axActUtlType1.GetDevice(name, out tempInt);
            if (tempInt == 1)
            {
                
                 buttonName.BackColor = Color.Lime;
                 tempVar = 1;

            }
            else
            {
                buttonName.BackColor = Color.Wheat;
                tempVar = 0;
            }
            return 0;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            try
            {
                if (output000==1)
                {
                    axActUtlType1.SetDevice("M40", 0);

                }
                else if (output000==0)
                {
                    axActUtlType1.SetDevice("M40", 1);
                }
                
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
        }
        private int cusSetStatus(int deviceNum, string deviceName)
        {
            try
            {
                 if (deviceNum==1)
                {
                    axActUtlType1.SetDevice(deviceName, 0);

                }
                else if (deviceNum==0)
                {
                    axActUtlType1.SetDevice(deviceName, 1);
                }
            }
            catch (Exception)
            {
                
                throw;
            }
            return 0;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            cusSetStatus(output001, "M41");
        }

        private void button19_Click(object sender, EventArgs e)
        {
            cusSetStatus(output002, "M42");
        }

        private void button21_Click(object sender, EventArgs e)
        {
            cusSetStatus(output004, "M44");
        }

        private void button22_Click(object sender, EventArgs e)
        {
            cusSetStatus(output005, "M45");
        }

        private void button23_Click(object sender, EventArgs e)
        {
            cusSetStatus(output007, "M46");
        }

        private void button27_Click(object sender, EventArgs e)
        {
            cusSetStatus(output012, "M49");
        }

     
    }
}
