﻿namespace fxplc_comm
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// 
        /// </summary>
        /// 
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.btnConnectPLC = new System.Windows.Forms.Button();
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tpMain = new System.Windows.Forms.TabPage();
            this.grpSetM = new System.Windows.Forms.GroupBox();
            this.btnM0235 = new System.Windows.Forms.Button();
            this.btnM0231 = new System.Windows.Forms.Button();
            this.btnM0233 = new System.Windows.Forms.Button();
            this.btnM0234 = new System.Windows.Forms.Button();
            this.btnM0232 = new System.Windows.Forms.Button();
            this.lblD212 = new System.Windows.Forms.Label();
            this.txtD212 = new System.Windows.Forms.TextBox();
            this.lblD211 = new System.Windows.Forms.Label();
            this.txtD211 = new System.Windows.Forms.TextBox();
            this.lblD210 = new System.Windows.Forms.Label();
            this.txtD210 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnWriteIn = new System.Windows.Forms.Button();
            this.txtD202 = new System.Windows.Forms.TextBox();
            this.lblD202 = new System.Windows.Forms.Label();
            this.txtD201 = new System.Windows.Forms.TextBox();
            this.lblD201 = new System.Windows.Forms.Label();
            this.lblD200 = new System.Windows.Forms.Label();
            this.txtD200 = new System.Windows.Forms.TextBox();
            this.btnX010 = new System.Windows.Forms.Button();
            this.btnX024 = new System.Windows.Forms.Button();
            this.btnX013 = new System.Windows.Forms.Button();
            this.btnX012 = new System.Windows.Forms.Button();
            this.btnX011 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnY017 = new System.Windows.Forms.Button();
            this.btnY016 = new System.Windows.Forms.Button();
            this.btnY015 = new System.Windows.Forms.Button();
            this.btnY014 = new System.Windows.Forms.Button();
            this.btnY013 = new System.Windows.Forms.Button();
            this.btnY006 = new System.Windows.Forms.Button();
            this.btnY003 = new System.Windows.Forms.Button();
            this.btnY012 = new System.Windows.Forms.Button();
            this.btnY010 = new System.Windows.Forms.Button();
            this.btnY011 = new System.Windows.Forms.Button();
            this.btnY007 = new System.Windows.Forms.Button();
            this.btnY005 = new System.Windows.Forms.Button();
            this.btnY004 = new System.Windows.Forms.Button();
            this.btnY002 = new System.Windows.Forms.Button();
            this.btnY001 = new System.Windows.Forms.Button();
            this.btnY000 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnX015 = new System.Windows.Forms.Button();
            this.btnX014 = new System.Windows.Forms.Button();
            this.btnX005 = new System.Windows.Forms.Button();
            this.btnX007 = new System.Windows.Forms.Button();
            this.btnX006 = new System.Windows.Forms.Button();
            this.btnX002 = new System.Windows.Forms.Button();
            this.btnX004 = new System.Windows.Forms.Button();
            this.btnX003 = new System.Windows.Forms.Button();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.ovalShapeY005 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShapeY012 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShapeY004 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.rectangleShape5 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape4 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape3 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape2 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.rectangleShape1 = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.tpSecond = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ComponentName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.作用 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabThird = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnExportLog = new System.Windows.Forms.Button();
            this.btnClearLog = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.btnStartTopProgram = new System.Windows.Forms.Button();
            this.grpPLCInfo = new System.Windows.Forms.GroupBox();
            this.txtPLCStationNumber = new System.Windows.Forms.TextBox();
            this.lblPLCStationNumber = new System.Windows.Forms.Label();
            this.txtPLCType = new System.Windows.Forms.TextBox();
            this.lblPLCType = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnSwitchStatus = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.语言ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.中文ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.englishToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.报警自定义ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.axActUtlType1 = new AxActUtlTypeLib.AxActUtlType();
            this.errorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabMain.SuspendLayout();
            this.tpMain.SuspendLayout();
            this.grpSetM.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tpSecond.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabThird.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.grpPLCInfo.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axActUtlType1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnConnectPLC
            // 
            this.btnConnectPLC.Location = new System.Drawing.Point(60, 102);
            this.btnConnectPLC.Name = "btnConnectPLC";
            this.btnConnectPLC.Size = new System.Drawing.Size(61, 23);
            this.btnConnectPLC.TabIndex = 1;
            this.btnConnectPLC.Text = "连接";
            this.btnConnectPLC.UseVisualStyleBackColor = true;
            this.btnConnectPLC.Click += new System.EventHandler(this.btnConnectPLC_Click);
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tpMain);
            this.tabMain.Controls.Add(this.tpSecond);
            this.tabMain.Controls.Add(this.tabThird);
            this.tabMain.Location = new System.Drawing.Point(8, 27);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(825, 660);
            this.tabMain.TabIndex = 2;
            // 
            // tpMain
            // 
            this.tpMain.Controls.Add(this.grpSetM);
            this.tpMain.Controls.Add(this.lblD212);
            this.tpMain.Controls.Add(this.txtD212);
            this.tpMain.Controls.Add(this.lblD211);
            this.tpMain.Controls.Add(this.txtD211);
            this.tpMain.Controls.Add(this.lblD210);
            this.tpMain.Controls.Add(this.txtD210);
            this.tpMain.Controls.Add(this.label10);
            this.tpMain.Controls.Add(this.label9);
            this.tpMain.Controls.Add(this.label8);
            this.tpMain.Controls.Add(this.label7);
            this.tpMain.Controls.Add(this.label6);
            this.tpMain.Controls.Add(this.btnWriteIn);
            this.tpMain.Controls.Add(this.txtD202);
            this.tpMain.Controls.Add(this.lblD202);
            this.tpMain.Controls.Add(this.txtD201);
            this.tpMain.Controls.Add(this.lblD201);
            this.tpMain.Controls.Add(this.lblD200);
            this.tpMain.Controls.Add(this.txtD200);
            this.tpMain.Controls.Add(this.btnX010);
            this.tpMain.Controls.Add(this.btnX024);
            this.tpMain.Controls.Add(this.btnX013);
            this.tpMain.Controls.Add(this.btnX012);
            this.tpMain.Controls.Add(this.btnX011);
            this.tpMain.Controls.Add(this.groupBox4);
            this.tpMain.Controls.Add(this.shapeContainer1);
            this.tpMain.Controls.Add(this.groupBox7);
            this.tpMain.Location = new System.Drawing.Point(4, 22);
            this.tpMain.Name = "tpMain";
            this.tpMain.Padding = new System.Windows.Forms.Padding(3);
            this.tpMain.Size = new System.Drawing.Size(817, 634);
            this.tpMain.TabIndex = 0;
            this.tpMain.Text = "PLC 运行监控";
            this.tpMain.UseVisualStyleBackColor = true;
            this.tpMain.Enter += new System.EventHandler(this.tpMain_Enter);
            // 
            // grpSetM
            // 
            this.grpSetM.Controls.Add(this.btnM0235);
            this.grpSetM.Controls.Add(this.btnM0231);
            this.grpSetM.Controls.Add(this.btnM0233);
            this.grpSetM.Controls.Add(this.btnM0234);
            this.grpSetM.Controls.Add(this.btnM0232);
            this.grpSetM.Location = new System.Drawing.Point(673, 372);
            this.grpSetM.Name = "grpSetM";
            this.grpSetM.Size = new System.Drawing.Size(135, 239);
            this.grpSetM.TabIndex = 6;
            this.grpSetM.TabStop = false;
            this.grpSetM.Text = "设置流水线方向";
            // 
            // btnM0235
            // 
            this.btnM0235.Location = new System.Drawing.Point(6, 200);
            this.btnM0235.Name = "btnM0235";
            this.btnM0235.Size = new System.Drawing.Size(123, 31);
            this.btnM0235.TabIndex = 6;
            this.btnM0235.Text = "(M0235)";
            this.btnM0235.UseVisualStyleBackColor = true;
            this.btnM0235.Click += new System.EventHandler(this.btnM0235_Click);
            this.btnM0235.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnM0235_KeyPress);
            // 
            // btnM0231
            // 
            this.btnM0231.Location = new System.Drawing.Point(6, 20);
            this.btnM0231.Name = "btnM0231";
            this.btnM0231.Size = new System.Drawing.Size(123, 31);
            this.btnM0231.TabIndex = 6;
            this.btnM0231.Text = "(M0231)";
            this.btnM0231.UseVisualStyleBackColor = true;
            this.btnM0231.Click += new System.EventHandler(this.btnM0231_Click);
            this.btnM0231.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnM0231_KeyPress);
            // 
            // btnM0233
            // 
            this.btnM0233.Location = new System.Drawing.Point(6, 110);
            this.btnM0233.Name = "btnM0233";
            this.btnM0233.Size = new System.Drawing.Size(123, 31);
            this.btnM0233.TabIndex = 6;
            this.btnM0233.Text = "(M0233)";
            this.btnM0233.UseVisualStyleBackColor = true;
            this.btnM0233.Click += new System.EventHandler(this.btnM0233_Click);
            this.btnM0233.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnM0233_KeyPress);
            // 
            // btnM0234
            // 
            this.btnM0234.Location = new System.Drawing.Point(6, 155);
            this.btnM0234.Name = "btnM0234";
            this.btnM0234.Size = new System.Drawing.Size(123, 31);
            this.btnM0234.TabIndex = 6;
            this.btnM0234.Text = "(M0234)";
            this.btnM0234.UseVisualStyleBackColor = true;
            this.btnM0234.Click += new System.EventHandler(this.btnM0234_Click);
            this.btnM0234.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnM0234_KeyPress);
            // 
            // btnM0232
            // 
            this.btnM0232.Location = new System.Drawing.Point(6, 65);
            this.btnM0232.Name = "btnM0232";
            this.btnM0232.Size = new System.Drawing.Size(123, 31);
            this.btnM0232.TabIndex = 6;
            this.btnM0232.Text = "(M0232)";
            this.btnM0232.UseVisualStyleBackColor = true;
            this.btnM0232.Click += new System.EventHandler(this.btnM0232_Click);
            this.btnM0232.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnM0232_KeyPress);
            // 
            // lblD212
            // 
            this.lblD212.AutoSize = true;
            this.lblD212.Location = new System.Drawing.Point(671, 271);
            this.lblD212.Name = "lblD212";
            this.lblD212.Size = new System.Drawing.Size(29, 12);
            this.lblD212.TabIndex = 4;
            this.lblD212.Text = "D212";
            this.lblD212.DoubleClick += new System.EventHandler(this.lblD212_DoubleClick);
            // 
            // txtD212
            // 
            this.txtD212.Location = new System.Drawing.Point(708, 288);
            this.txtD212.Name = "txtD212";
            this.txtD212.Size = new System.Drawing.Size(100, 21);
            this.txtD212.TabIndex = 3;
            // 
            // lblD211
            // 
            this.lblD211.AutoSize = true;
            this.lblD211.Location = new System.Drawing.Point(671, 219);
            this.lblD211.Name = "lblD211";
            this.lblD211.Size = new System.Drawing.Size(29, 12);
            this.lblD211.TabIndex = 4;
            this.lblD211.Text = "D211";
            this.lblD211.DoubleClick += new System.EventHandler(this.lblD211_DoubleClick);
            // 
            // txtD211
            // 
            this.txtD211.Location = new System.Drawing.Point(708, 238);
            this.txtD211.Name = "txtD211";
            this.txtD211.Size = new System.Drawing.Size(100, 21);
            this.txtD211.TabIndex = 3;
            // 
            // lblD210
            // 
            this.lblD210.AutoSize = true;
            this.lblD210.Location = new System.Drawing.Point(671, 169);
            this.lblD210.Name = "lblD210";
            this.lblD210.Size = new System.Drawing.Size(29, 12);
            this.lblD210.TabIndex = 4;
            this.lblD210.Text = "D210";
            this.lblD210.DoubleClick += new System.EventHandler(this.lblD210_DoubleClick);
            // 
            // txtD210
            // 
            this.txtD210.Location = new System.Drawing.Point(708, 188);
            this.txtD210.Name = "txtD210";
            this.txtD210.Size = new System.Drawing.Size(100, 21);
            this.txtD210.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(438, 193);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 7;
            this.label10.Text = "气缸低位";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(95, 98);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 12);
            this.label9.TabIndex = 7;
            this.label9.Text = "进玻璃到位";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(594, 97);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "进玻璃开始";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(438, 107);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 7;
            this.label7.Text = "气缸高位";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(248, 139);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 12);
            this.label6.TabIndex = 7;
            this.label6.Tag = "高位玻璃存在";
            this.label6.Text = "高位玻璃存在";
            // 
            // btnWriteIn
            // 
            this.btnWriteIn.Enabled = false;
            this.btnWriteIn.Location = new System.Drawing.Point(733, 333);
            this.btnWriteIn.Name = "btnWriteIn";
            this.btnWriteIn.Size = new System.Drawing.Size(75, 23);
            this.btnWriteIn.TabIndex = 6;
            this.btnWriteIn.Text = "写入";
            this.btnWriteIn.UseVisualStyleBackColor = true;
            this.btnWriteIn.Click += new System.EventHandler(this.btnWriteIn_Click);
            // 
            // txtD202
            // 
            this.txtD202.Location = new System.Drawing.Point(708, 138);
            this.txtD202.Name = "txtD202";
            this.txtD202.Size = new System.Drawing.Size(100, 21);
            this.txtD202.TabIndex = 3;
            // 
            // lblD202
            // 
            this.lblD202.AutoSize = true;
            this.lblD202.Location = new System.Drawing.Point(671, 123);
            this.lblD202.Name = "lblD202";
            this.lblD202.Size = new System.Drawing.Size(125, 12);
            this.lblD202.TabIndex = 4;
            this.lblD202.Text = "排版机进玻璃超时(ms)";
            // 
            // txtD201
            // 
            this.txtD201.Location = new System.Drawing.Point(708, 88);
            this.txtD201.Name = "txtD201";
            this.txtD201.Size = new System.Drawing.Size(100, 21);
            this.txtD201.TabIndex = 3;
            // 
            // lblD201
            // 
            this.lblD201.AutoSize = true;
            this.lblD201.Location = new System.Drawing.Point(671, 67);
            this.lblD201.Name = "lblD201";
            this.lblD201.Size = new System.Drawing.Size(89, 12);
            this.lblD201.TabIndex = 4;
            this.lblD201.Text = "进玻璃超时(ms)";
            // 
            // lblD200
            // 
            this.lblD200.AutoSize = true;
            this.lblD200.Location = new System.Drawing.Point(671, 17);
            this.lblD200.Name = "lblD200";
            this.lblD200.Size = new System.Drawing.Size(119, 12);
            this.lblD200.TabIndex = 4;
            this.lblD200.Text = "进玻璃到位延时(ms）";
            // 
            // txtD200
            // 
            this.txtD200.Location = new System.Drawing.Point(708, 38);
            this.txtD200.Name = "txtD200";
            this.txtD200.Size = new System.Drawing.Size(100, 21);
            this.txtD200.TabIndex = 3;
            this.txtD200.Click += new System.EventHandler(this.textBox3_Click);
            // 
            // btnX010
            // 
            this.btnX010.Enabled = false;
            this.btnX010.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX010.Location = new System.Drawing.Point(187, 135);
            this.btnX010.Name = "btnX010";
            this.btnX010.Size = new System.Drawing.Size(55, 20);
            this.btnX010.TabIndex = 2;
            this.btnX010.Text = "(X010)";
            this.btnX010.UseVisualStyleBackColor = true;
            // 
            // btnX024
            // 
            this.btnX024.Enabled = false;
            this.btnX024.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX024.Location = new System.Drawing.Point(530, 89);
            this.btnX024.Name = "btnX024";
            this.btnX024.Size = new System.Drawing.Size(55, 20);
            this.btnX024.TabIndex = 2;
            this.btnX024.Text = "(X024)";
            this.btnX024.UseVisualStyleBackColor = true;
            // 
            // btnX013
            // 
            this.btnX013.Enabled = false;
            this.btnX013.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX013.Location = new System.Drawing.Point(377, 185);
            this.btnX013.Name = "btnX013";
            this.btnX013.Size = new System.Drawing.Size(55, 20);
            this.btnX013.TabIndex = 2;
            this.btnX013.Text = "(X013)";
            this.btnX013.UseVisualStyleBackColor = true;
            // 
            // btnX012
            // 
            this.btnX012.Enabled = false;
            this.btnX012.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX012.Location = new System.Drawing.Point(377, 99);
            this.btnX012.Name = "btnX012";
            this.btnX012.Size = new System.Drawing.Size(55, 20);
            this.btnX012.TabIndex = 2;
            this.btnX012.Text = "(X012)";
            this.btnX012.UseVisualStyleBackColor = true;
            // 
            // btnX011
            // 
            this.btnX011.Enabled = false;
            this.btnX011.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX011.Location = new System.Drawing.Point(34, 89);
            this.btnX011.Name = "btnX011";
            this.btnX011.Size = new System.Drawing.Size(55, 20);
            this.btnX011.TabIndex = 2;
            this.btnX011.Text = "(X011)";
            this.btnX011.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.groupBox6);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Location = new System.Drawing.Point(13, 247);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(654, 381);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "输入输出信号";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnY017);
            this.groupBox6.Controls.Add(this.btnY016);
            this.groupBox6.Controls.Add(this.btnY015);
            this.groupBox6.Controls.Add(this.btnY014);
            this.groupBox6.Controls.Add(this.btnY013);
            this.groupBox6.Controls.Add(this.btnY006);
            this.groupBox6.Controls.Add(this.btnY003);
            this.groupBox6.Controls.Add(this.btnY012);
            this.groupBox6.Controls.Add(this.btnY010);
            this.groupBox6.Controls.Add(this.btnY011);
            this.groupBox6.Controls.Add(this.btnY007);
            this.groupBox6.Controls.Add(this.btnY005);
            this.groupBox6.Controls.Add(this.btnY004);
            this.groupBox6.Controls.Add(this.btnY002);
            this.groupBox6.Controls.Add(this.btnY001);
            this.groupBox6.Controls.Add(this.btnY000);
            this.groupBox6.Location = new System.Drawing.Point(16, 159);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(630, 217);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "输出信号";
            // 
            // btnY017
            // 
            this.btnY017.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY017.Location = new System.Drawing.Point(318, 172);
            this.btnY017.Name = "btnY017";
            this.btnY017.Size = new System.Drawing.Size(150, 32);
            this.btnY017.TabIndex = 0;
            this.btnY017.Text = "(Y017)备用";
            this.btnY017.UseVisualStyleBackColor = true;
            this.btnY017.Click += new System.EventHandler(this.btnY017_Click);
            this.btnY017.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY017_KeyPress);
            // 
            // btnY016
            // 
            this.btnY016.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY016.Location = new System.Drawing.Point(162, 172);
            this.btnY016.Name = "btnY016";
            this.btnY016.Size = new System.Drawing.Size(150, 32);
            this.btnY016.TabIndex = 0;
            this.btnY016.Text = "(Y016)备用";
            this.btnY016.UseVisualStyleBackColor = true;
            this.btnY016.Click += new System.EventHandler(this.btnY016_Click);
            this.btnY016.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY016_KeyPress);
            // 
            // btnY015
            // 
            this.btnY015.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY015.Location = new System.Drawing.Point(7, 172);
            this.btnY015.Name = "btnY015";
            this.btnY015.Size = new System.Drawing.Size(150, 32);
            this.btnY015.TabIndex = 0;
            this.btnY015.Text = "(Y015)备用";
            this.btnY015.UseVisualStyleBackColor = true;
            this.btnY015.Click += new System.EventHandler(this.btnY015_Click);
            this.btnY015.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY015_KeyPress);
            // 
            // btnY014
            // 
            this.btnY014.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY014.Location = new System.Drawing.Point(472, 134);
            this.btnY014.Name = "btnY014";
            this.btnY014.Size = new System.Drawing.Size(150, 32);
            this.btnY014.TabIndex = 0;
            this.btnY014.Text = "(Y014)备用";
            this.btnY014.UseVisualStyleBackColor = true;
            this.btnY014.Click += new System.EventHandler(this.btnY014_Click);
            this.btnY014.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY014_KeyPress);
            // 
            // btnY013
            // 
            this.btnY013.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY013.Location = new System.Drawing.Point(317, 134);
            this.btnY013.Name = "btnY013";
            this.btnY013.Size = new System.Drawing.Size(150, 32);
            this.btnY013.TabIndex = 0;
            this.btnY013.Text = "(Y013)备用";
            this.btnY013.UseVisualStyleBackColor = true;
            this.btnY013.Click += new System.EventHandler(this.btnY013_Click);
            this.btnY013.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY013_KeyPress);
            // 
            // btnY006
            // 
            this.btnY006.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY006.Location = new System.Drawing.Point(162, 134);
            this.btnY006.Name = "btnY006";
            this.btnY006.Size = new System.Drawing.Size(150, 32);
            this.btnY006.TabIndex = 0;
            this.btnY006.Text = "(Y006)备用";
            this.btnY006.UseVisualStyleBackColor = true;
            this.btnY006.Click += new System.EventHandler(this.btnY006_Click);
            this.btnY006.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY006_KeyPress);
            // 
            // btnY003
            // 
            this.btnY003.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY003.Location = new System.Drawing.Point(7, 134);
            this.btnY003.Name = "btnY003";
            this.btnY003.Size = new System.Drawing.Size(150, 32);
            this.btnY003.TabIndex = 0;
            this.btnY003.Text = "(Y003)备用";
            this.btnY003.UseVisualStyleBackColor = true;
            this.btnY003.Click += new System.EventHandler(this.btnY003_Click);
            this.btnY003.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY003_KeyPress);
            // 
            // btnY012
            // 
            this.btnY012.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY012.Location = new System.Drawing.Point(7, 96);
            this.btnY012.Name = "btnY012";
            this.btnY012.Size = new System.Drawing.Size(190, 32);
            this.btnY012.TabIndex = 0;
            this.btnY012.Text = "(Y012)电磁阀";
            this.btnY012.UseVisualStyleBackColor = true;
            this.btnY012.Click += new System.EventHandler(this.btnY012_Click);
            this.btnY012.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY012_KeyPress);
            // 
            // btnY010
            // 
            this.btnY010.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY010.Location = new System.Drawing.Point(221, 96);
            this.btnY010.Name = "btnY010";
            this.btnY010.Size = new System.Drawing.Size(190, 32);
            this.btnY010.TabIndex = 0;
            this.btnY010.Text = "(Y010)停止指示";
            this.btnY010.UseVisualStyleBackColor = true;
            this.btnY010.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY010_KeyPress);
            // 
            // btnY011
            // 
            this.btnY011.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY011.Location = new System.Drawing.Point(433, 96);
            this.btnY011.Name = "btnY011";
            this.btnY011.Size = new System.Drawing.Size(190, 32);
            this.btnY011.TabIndex = 0;
            this.btnY011.Text = "(Y011)运行指示";
            this.btnY011.UseVisualStyleBackColor = true;
            this.btnY011.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY011_KeyPress);
            // 
            // btnY007
            // 
            this.btnY007.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY007.Location = new System.Drawing.Point(433, 59);
            this.btnY007.Name = "btnY007";
            this.btnY007.Size = new System.Drawing.Size(190, 32);
            this.btnY007.TabIndex = 0;
            this.btnY007.Text = "(Y007)暂存台电机";
            this.btnY007.UseVisualStyleBackColor = true;
            this.btnY007.Click += new System.EventHandler(this.btnY007_Click);
            this.btnY007.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY007_KeyPress);
            // 
            // btnY005
            // 
            this.btnY005.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY005.Location = new System.Drawing.Point(221, 58);
            this.btnY005.Name = "btnY005";
            this.btnY005.Size = new System.Drawing.Size(190, 32);
            this.btnY005.TabIndex = 0;
            this.btnY005.Text = "(Y005)转向电机";
            this.btnY005.UseVisualStyleBackColor = true;
            this.btnY005.Click += new System.EventHandler(this.btnY005_Click);
            this.btnY005.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY005_KeyPress);
            // 
            // btnY004
            // 
            this.btnY004.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY004.Location = new System.Drawing.Point(7, 58);
            this.btnY004.Name = "btnY004";
            this.btnY004.Size = new System.Drawing.Size(190, 32);
            this.btnY004.TabIndex = 0;
            this.btnY004.Text = "(Y004)流水线方向电机";
            this.btnY004.UseVisualStyleBackColor = true;
            this.btnY004.Click += new System.EventHandler(this.btnY004_Click);
            this.btnY004.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY004_KeyPress);
            // 
            // btnY002
            // 
            this.btnY002.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY002.Location = new System.Drawing.Point(433, 21);
            this.btnY002.Name = "btnY002";
            this.btnY002.Size = new System.Drawing.Size(190, 32);
            this.btnY002.TabIndex = 0;
            this.btnY002.Text = "(Y002)向铺设位传玻璃申请";
            this.btnY002.UseVisualStyleBackColor = true;
            this.btnY002.Click += new System.EventHandler(this.btnY002_Click);
            this.btnY002.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY002_KeyPress);
            // 
            // btnY001
            // 
            this.btnY001.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY001.Location = new System.Drawing.Point(221, 20);
            this.btnY001.Name = "btnY001";
            this.btnY001.Size = new System.Drawing.Size(190, 32);
            this.btnY001.TabIndex = 0;
            this.btnY001.Text = "(Y001)玻璃传出申请";
            this.btnY001.UseVisualStyleBackColor = true;
            this.btnY001.Click += new System.EventHandler(this.btnY001_Click);
            this.btnY001.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY001_KeyPress);
            // 
            // btnY000
            // 
            this.btnY000.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnY000.Location = new System.Drawing.Point(7, 20);
            this.btnY000.Name = "btnY000";
            this.btnY000.Size = new System.Drawing.Size(190, 32);
            this.btnY000.TabIndex = 0;
            this.btnY000.Text = "(Y000)允许流水线进玻璃";
            this.btnY000.UseVisualStyleBackColor = true;
            this.btnY000.Click += new System.EventHandler(this.btnY000_Click);
            this.btnY000.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnY000_KeyPress);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnX015);
            this.groupBox5.Controls.Add(this.btnX014);
            this.groupBox5.Controls.Add(this.btnX005);
            this.groupBox5.Controls.Add(this.btnX007);
            this.groupBox5.Controls.Add(this.btnX006);
            this.groupBox5.Controls.Add(this.btnX002);
            this.groupBox5.Controls.Add(this.btnX004);
            this.groupBox5.Controls.Add(this.btnX003);
            this.groupBox5.Location = new System.Drawing.Point(16, 20);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(630, 120);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "对接输入信号";
            // 
            // btnX015
            // 
            this.btnX015.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX015.Location = new System.Drawing.Point(513, 73);
            this.btnX015.Name = "btnX015";
            this.btnX015.Size = new System.Drawing.Size(110, 32);
            this.btnX015.TabIndex = 0;
            this.btnX015.Text = "(X015)备用";
            this.btnX015.UseVisualStyleBackColor = true;
            this.btnX015.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnX015_KeyPress);
            // 
            // btnX014
            // 
            this.btnX014.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX014.Location = new System.Drawing.Point(387, 73);
            this.btnX014.Name = "btnX014";
            this.btnX014.Size = new System.Drawing.Size(110, 32);
            this.btnX014.TabIndex = 0;
            this.btnX014.Text = "(X014)备用";
            this.btnX014.UseVisualStyleBackColor = true;
            this.btnX014.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnX014_KeyPress);
            // 
            // btnX005
            // 
            this.btnX005.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX005.Location = new System.Drawing.Point(418, 19);
            this.btnX005.Name = "btnX005";
            this.btnX005.Size = new System.Drawing.Size(205, 32);
            this.btnX005.TabIndex = 0;
            this.btnX005.Text = "(X005)串联2号排版机玻璃传入允许";
            this.btnX005.UseVisualStyleBackColor = true;
            this.btnX005.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnX005_KeyPress);
            // 
            // btnX007
            // 
            this.btnX007.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX007.Location = new System.Drawing.Point(261, 73);
            this.btnX007.Name = "btnX007";
            this.btnX007.Size = new System.Drawing.Size(110, 32);
            this.btnX007.TabIndex = 0;
            this.btnX007.Text = "(X007)备用";
            this.btnX007.UseVisualStyleBackColor = true;
            this.btnX007.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnX007_KeyPress);
            // 
            // btnX006
            // 
            this.btnX006.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX006.Location = new System.Drawing.Point(135, 73);
            this.btnX006.Name = "btnX006";
            this.btnX006.Size = new System.Drawing.Size(110, 32);
            this.btnX006.TabIndex = 0;
            this.btnX006.Text = "(X006)备用";
            this.btnX006.UseVisualStyleBackColor = true;
            this.btnX006.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnX006_KeyPress);
            // 
            // btnX002
            // 
            this.btnX002.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX002.Location = new System.Drawing.Point(9, 73);
            this.btnX002.Name = "btnX002";
            this.btnX002.Size = new System.Drawing.Size(110, 32);
            this.btnX002.TabIndex = 0;
            this.btnX002.Text = "(X002)备用";
            this.btnX002.UseVisualStyleBackColor = true;
            this.btnX002.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnX002_KeyPress);
            // 
            // btnX004
            // 
            this.btnX004.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX004.Location = new System.Drawing.Point(213, 20);
            this.btnX004.Name = "btnX004";
            this.btnX004.Size = new System.Drawing.Size(190, 32);
            this.btnX004.TabIndex = 0;
            this.btnX004.Text = "(X004)排版机允许进料";
            this.btnX004.UseVisualStyleBackColor = true;
            this.btnX004.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnX004_KeyPress);
            // 
            // btnX003
            // 
            this.btnX003.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX003.Location = new System.Drawing.Point(7, 19);
            this.btnX003.Name = "btnX003";
            this.btnX003.Size = new System.Drawing.Size(190, 32);
            this.btnX003.TabIndex = 0;
            this.btnX003.Text = "(X003)流水线申请进玻璃";
            this.btnX003.UseVisualStyleBackColor = true;
            this.btnX003.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnX003_KeyPress);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(3, 3);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.ovalShapeY005,
            this.ovalShapeY012,
            this.ovalShapeY004,
            this.rectangleShape5,
            this.rectangleShape4,
            this.rectangleShape3,
            this.rectangleShape2,
            this.rectangleShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(811, 628);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // ovalShapeY005
            // 
            this.ovalShapeY005.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.ovalShapeY005.Location = new System.Drawing.Point(131, 166);
            this.ovalShapeY005.Name = "ovalShapeY005";
            this.ovalShapeY005.Size = new System.Drawing.Size(22, 22);
            // 
            // ovalShapeY012
            // 
            this.ovalShapeY012.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.ovalShapeY012.Location = new System.Drawing.Point(358, 136);
            this.ovalShapeY012.Name = "ovalShapeY012";
            this.ovalShapeY012.Size = new System.Drawing.Size(22, 22);
            // 
            // ovalShapeY004
            // 
            this.ovalShapeY004.BackColor = System.Drawing.Color.Transparent;
            this.ovalShapeY004.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.ovalShapeY004.Location = new System.Drawing.Point(31, 42);
            this.ovalShapeY004.Name = "ovalShapeY004";
            this.ovalShapeY004.Size = new System.Drawing.Size(22, 22);
            // 
            // rectangleShape5
            // 
            this.rectangleShape5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.rectangleShape5.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.rectangleShape5.Location = new System.Drawing.Point(502, 95);
            this.rectangleShape5.Name = "rectangleShape5";
            this.rectangleShape5.Size = new System.Drawing.Size(23, 94);
            // 
            // rectangleShape4
            // 
            this.rectangleShape4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.rectangleShape4.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.rectangleShape4.Location = new System.Drawing.Point(330, 96);
            this.rectangleShape4.Name = "rectangleShape4";
            this.rectangleShape4.Size = new System.Drawing.Size(23, 94);
            // 
            // rectangleShape3
            // 
            this.rectangleShape3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.rectangleShape3.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.rectangleShape3.Location = new System.Drawing.Point(161, 96);
            this.rectangleShape3.Name = "rectangleShape3";
            this.rectangleShape3.Size = new System.Drawing.Size(23, 94);
            // 
            // rectangleShape2
            // 
            this.rectangleShape2.BackColor = System.Drawing.Color.Transparent;
            this.rectangleShape2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.rectangleShape2.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.rectangleShape2.Location = new System.Drawing.Point(30, 212);
            this.rectangleShape2.Name = "rectangleShape2";
            this.rectangleShape2.Size = new System.Drawing.Size(608, 16);
            // 
            // rectangleShape1
            // 
            this.rectangleShape1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.rectangleShape1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.rectangleShape1.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.rectangleShape1.Location = new System.Drawing.Point(29, 70);
            this.rectangleShape1.Name = "rectangleShape1";
            this.rectangleShape1.Size = new System.Drawing.Size(608, 16);
            this.rectangleShape1.UseWaitCursor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Location = new System.Drawing.Point(15, 10);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(650, 239);
            this.groupBox7.TabIndex = 5;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "进玻璃位图示";
            // 
            // tpSecond
            // 
            this.tpSecond.Controls.Add(this.dataGridView1);
            this.tpSecond.Location = new System.Drawing.Point(4, 22);
            this.tpSecond.Name = "tpSecond";
            this.tpSecond.Padding = new System.Windows.Forms.Padding(3);
            this.tpSecond.Size = new System.Drawing.Size(817, 634);
            this.tpSecond.TabIndex = 1;
            this.tpSecond.Text = "PLC IO表";
            this.tpSecond.UseVisualStyleBackColor = true;
            this.tpSecond.Enter += new System.EventHandler(this.tpSecond_Enter);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ComponentName,
            this.作用});
            this.dataGridView1.Location = new System.Drawing.Point(6, 3);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(445, 613);
            this.dataGridView1.TabIndex = 2;
            // 
            // ComponentName
            // 
            this.ComponentName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ComponentName.HeaderText = "软元件";
            this.ComponentName.Name = "ComponentName";
            this.ComponentName.ReadOnly = true;
            // 
            // 作用
            // 
            this.作用.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.作用.HeaderText = "名称";
            this.作用.Name = "作用";
            this.作用.ReadOnly = true;
            // 
            // tabThird
            // 
            this.tabThird.Controls.Add(this.panel2);
            this.tabThird.Controls.Add(this.panel1);
            this.tabThird.Location = new System.Drawing.Point(4, 22);
            this.tabThird.Name = "tabThird";
            this.tabThird.Size = new System.Drawing.Size(817, 634);
            this.tabThird.TabIndex = 2;
            this.tabThird.Text = "报警日志";
            this.tabThird.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnExportLog);
            this.panel2.Controls.Add(this.btnClearLog);
            this.panel2.Location = new System.Drawing.Point(416, 538);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(334, 45);
            this.panel2.TabIndex = 2;
            // 
            // btnExportLog
            // 
            this.btnExportLog.Location = new System.Drawing.Point(5, 3);
            this.btnExportLog.Name = "btnExportLog";
            this.btnExportLog.Size = new System.Drawing.Size(127, 39);
            this.btnExportLog.TabIndex = 0;
            this.btnExportLog.Text = "导出日志文件";
            this.btnExportLog.UseVisualStyleBackColor = true;
            this.btnExportLog.Click += new System.EventHandler(this.btnExportLog_Click);
            // 
            // btnClearLog
            // 
            this.btnClearLog.Location = new System.Drawing.Point(222, 3);
            this.btnClearLog.Name = "btnClearLog";
            this.btnClearLog.Size = new System.Drawing.Size(95, 39);
            this.btnClearLog.TabIndex = 0;
            this.btnClearLog.Text = "清除日志";
            this.btnClearLog.UseVisualStyleBackColor = true;
            this.btnClearLog.Click += new System.EventHandler(this.btnClearLog_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataGridView2);
            this.panel1.Location = new System.Drawing.Point(3, 8);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 512);
            this.panel1.TabIndex = 1;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToOrderColumns = true;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(0, 5);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(780, 427);
            this.dataGridView2.TabIndex = 0;
            // 
            // btnStartTopProgram
            // 
            this.btnStartTopProgram.Enabled = false;
            this.btnStartTopProgram.Location = new System.Drawing.Point(848, 219);
            this.btnStartTopProgram.Name = "btnStartTopProgram";
            this.btnStartTopProgram.Size = new System.Drawing.Size(127, 35);
            this.btnStartTopProgram.TabIndex = 0;
            this.btnStartTopProgram.Text = "启动/停止PLC程序";
            this.btnStartTopProgram.UseVisualStyleBackColor = true;
            this.btnStartTopProgram.Click += new System.EventHandler(this.btnStartStopProgram_Click);
            // 
            // grpPLCInfo
            // 
            this.grpPLCInfo.Controls.Add(this.txtPLCStationNumber);
            this.grpPLCInfo.Controls.Add(this.lblPLCStationNumber);
            this.grpPLCInfo.Controls.Add(this.txtPLCType);
            this.grpPLCInfo.Controls.Add(this.lblPLCType);
            this.grpPLCInfo.Controls.Add(this.btnConnectPLC);
            this.grpPLCInfo.Location = new System.Drawing.Point(839, 37);
            this.grpPLCInfo.Name = "grpPLCInfo";
            this.grpPLCInfo.Size = new System.Drawing.Size(142, 163);
            this.grpPLCInfo.TabIndex = 3;
            this.grpPLCInfo.TabStop = false;
            this.grpPLCInfo.Text = "PLC信息";
            // 
            // txtPLCStationNumber
            // 
            this.txtPLCStationNumber.Location = new System.Drawing.Point(85, 20);
            this.txtPLCStationNumber.Name = "txtPLCStationNumber";
            this.txtPLCStationNumber.Size = new System.Drawing.Size(51, 21);
            this.txtPLCStationNumber.TabIndex = 5;
            this.txtPLCStationNumber.Text = "3";
            this.txtPLCStationNumber.Click += new System.EventHandler(this.textBox2_Click);
            // 
            // lblPLCStationNumber
            // 
            this.lblPLCStationNumber.AutoSize = true;
            this.lblPLCStationNumber.Location = new System.Drawing.Point(11, 25);
            this.lblPLCStationNumber.Name = "lblPLCStationNumber";
            this.lblPLCStationNumber.Size = new System.Drawing.Size(53, 12);
            this.lblPLCStationNumber.TabIndex = 4;
            this.lblPLCStationNumber.Text = "PLC站号:";
            // 
            // txtPLCType
            // 
            this.txtPLCType.Location = new System.Drawing.Point(85, 58);
            this.txtPLCType.Name = "txtPLCType";
            this.txtPLCType.ReadOnly = true;
            this.txtPLCType.Size = new System.Drawing.Size(51, 21);
            this.txtPLCType.TabIndex = 3;
            // 
            // lblPLCType
            // 
            this.lblPLCType.AutoSize = true;
            this.lblPLCType.Location = new System.Drawing.Point(11, 61);
            this.lblPLCType.Name = "lblPLCType";
            this.lblPLCType.Size = new System.Drawing.Size(53, 12);
            this.lblPLCType.TabIndex = 2;
            this.lblPLCType.Text = "PLC型号:";
            // 
            // statusStrip1
            // 
            this.statusStrip1.AutoSize = false;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 707);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1008, 22);
            this.statusStrip1.Stretch = false;
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.Red;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(793, 17);
            this.toolStripStatusLabel1.Spring = true;
            this.toolStripStatusLabel1.Click += new System.EventHandler(this.toolStripStatusLabel1_Click);
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.AutoSize = false;
            this.toolStripStatusLabel2.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.toolStripStatusLabel2.BorderStyle = System.Windows.Forms.Border3DStyle.Bump;
            this.toolStripStatusLabel2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(200, 17);
            this.toolStripStatusLabel2.Text = "PLC未连接";
            this.toolStripStatusLabel2.ToolTipText = "PLC状态";
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.tmrGetSetStatus_Tick);
            // 
            // btnSwitchStatus
            // 
            this.btnSwitchStatus.Enabled = false;
            this.btnSwitchStatus.Location = new System.Drawing.Point(848, 296);
            this.btnSwitchStatus.Name = "btnSwitchStatus";
            this.btnSwitchStatus.Size = new System.Drawing.Size(127, 35);
            this.btnSwitchStatus.TabIndex = 2;
            this.btnSwitchStatus.Text = "手动/自动切换";
            this.btnSwitchStatus.UseVisualStyleBackColor = true;
            this.btnSwitchStatus.Click += new System.EventHandler(this.btnSwitchStatus_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1008, 25);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.语言ToolStripMenuItem,
            this.报警自定义ToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(44, 21);
            this.toolStripMenuItem1.Text = "设置";
            // 
            // 语言ToolStripMenuItem
            // 
            this.语言ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.中文ToolStripMenuItem,
            this.englishToolStripMenuItem});
            this.语言ToolStripMenuItem.Name = "语言ToolStripMenuItem";
            this.语言ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.语言ToolStripMenuItem.Text = "语言";
            // 
            // 中文ToolStripMenuItem
            // 
            this.中文ToolStripMenuItem.Name = "中文ToolStripMenuItem";
            this.中文ToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.中文ToolStripMenuItem.Text = "中文";
            this.中文ToolStripMenuItem.Click += new System.EventHandler(this.中文ToolStripMenuItem_Click_1);
            // 
            // englishToolStripMenuItem
            // 
            this.englishToolStripMenuItem.Name = "englishToolStripMenuItem";
            this.englishToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.englishToolStripMenuItem.Text = "English";
            this.englishToolStripMenuItem.Click += new System.EventHandler(this.englishToolStripMenuItem_Click_1);
            // 
            // 报警自定义ToolStripMenuItem
            // 
            this.报警自定义ToolStripMenuItem.Name = "报警自定义ToolStripMenuItem";
            this.报警自定义ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.报警自定义ToolStripMenuItem.Text = "报警自定义";
            this.报警自定义ToolStripMenuItem.Click += new System.EventHandler(this.报警自定义ToolStripMenuItem_Click);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "PLC监控";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseClick);
            // 
            // axActUtlType1
            // 
            this.axActUtlType1.Enabled = true;
            this.axActUtlType1.Location = new System.Drawing.Point(1167, 613);
            this.axActUtlType1.Name = "axActUtlType1";
            this.axActUtlType1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axActUtlType1.OcxState")));
            this.axActUtlType1.Size = new System.Drawing.Size(32, 32);
            this.axActUtlType1.TabIndex = 0;
            // 
            // errorBindingSource
            // 
            this.errorBindingSource.DataSource = typeof(fxplc_comm.Error);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1008, 729);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tabMain);
            this.Controls.Add(this.btnSwitchStatus);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.grpPLCInfo);
            this.Controls.Add(this.btnStartTopProgram);
            this.Controls.Add(this.axActUtlType1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "排版机PLC";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.tabMain.ResumeLayout(false);
            this.tpMain.ResumeLayout(false);
            this.tpMain.PerformLayout();
            this.grpSetM.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.tpSecond.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabThird.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.grpPLCInfo.ResumeLayout(false);
            this.grpPLCInfo.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axActUtlType1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxActUtlTypeLib.AxActUtlType axActUtlType1;
        private System.Windows.Forms.Button btnConnectPLC;
        private System.Windows.Forms.TabPage tpMain;
        private System.Windows.Forms.TabPage tpSecond;
        private System.Windows.Forms.GroupBox grpPLCInfo;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.TextBox txtPLCType;
        private System.Windows.Forms.Label lblPLCType;
        private System.Windows.Forms.Button btnStartTopProgram;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox txtPLCStationNumber;
        private System.Windows.Forms.Label lblPLCStationNumber;
        private System.Windows.Forms.Button btnSwitchStatus;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape1;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShapeY004;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape5;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape4;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape3;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape rectangleShape2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox5;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShapeY012;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.TextBox txtD202;
        private System.Windows.Forms.Label lblD202;
        private System.Windows.Forms.TextBox txtD201;
        private System.Windows.Forms.Label lblD201;
        private System.Windows.Forms.Label lblD200;
        private System.Windows.Forms.TextBox txtD200;
        private System.Windows.Forms.Button btnX010;
        private System.Windows.Forms.Button btnX024;
        private System.Windows.Forms.Button btnX013;
        private System.Windows.Forms.Button btnX012;
        private System.Windows.Forms.Button btnX011;
        private System.Windows.Forms.Button btnY012;
        private System.Windows.Forms.Button btnY010;
        private System.Windows.Forms.Button btnY011;
        private System.Windows.Forms.Button btnY007;
        private System.Windows.Forms.Button btnY005;
        private System.Windows.Forms.Button btnY004;
        private System.Windows.Forms.Button btnY002;
        private System.Windows.Forms.Button btnY001;
        private System.Windows.Forms.Button btnY000;
        private System.Windows.Forms.Button btnX005;
        private System.Windows.Forms.Button btnX004;
        private System.Windows.Forms.Button btnX003;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btnWriteIn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShapeY005;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        public System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.DataGridViewTextBoxColumn ComponentName;
        private System.Windows.Forms.DataGridViewTextBoxColumn 作用;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 语言ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 报警自定义ToolStripMenuItem;
        private System.Windows.Forms.Button btnM0231;
        private System.Windows.Forms.Button btnY003;
        private System.Windows.Forms.Button btnY006;
        private System.Windows.Forms.Button btnY013;
        private System.Windows.Forms.Button btnY017;
        private System.Windows.Forms.Button btnY016;
        private System.Windows.Forms.Button btnY015;
        private System.Windows.Forms.Button btnY014;
        private System.Windows.Forms.Button btnM0235;
        private System.Windows.Forms.Button btnM0234;
        private System.Windows.Forms.Button btnM0233;
        private System.Windows.Forms.Button btnM0232;
        private System.Windows.Forms.Button btnX006;
        private System.Windows.Forms.Button btnX002;
        private System.Windows.Forms.Button btnX007;
        private System.Windows.Forms.Button btnX014;
        private System.Windows.Forms.Button btnX015;
        private System.Windows.Forms.Label lblD212;
        private System.Windows.Forms.TextBox txtD212;
        private System.Windows.Forms.Label lblD211;
        private System.Windows.Forms.TextBox txtD211;
        private System.Windows.Forms.Label lblD210;
        private System.Windows.Forms.TextBox txtD210;
        private System.Windows.Forms.GroupBox grpSetM;
        private System.Windows.Forms.TabPage tabThird;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnExportLog;
        private System.Windows.Forms.Button btnClearLog;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ToolStripMenuItem 中文ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem englishToolStripMenuItem;
        public System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource errorBindingSource;
        
    }
}

