﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace fxplc_comm
{
    public partial class FrmCustomError : Form
    {
        //错误列表
      public  List<Error> ErrorList = new System.Collections.Generic.List<Error>();
      public List<Error> Errors = new System.Collections.Generic.List<Error>();
        public FrmCustomError()
        {
          
            InitializeComponent();
           // ErrorHandle ErrorHandle1 = new ErrorHandle();
            InitErrorList();
            foreach (Error item in ErrorList)
            {

                dgvErrors.Rows.Add(item.toArray());
            }
        }
        public void InitErrorList()
        {
            try
            {
                using (StreamReader sr = new StreamReader("CustomError.txt"))
                {

                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        Error error = new Error();
                        string[] elements = line.Split(',');
                        error.ID = elements[0];
                        error.Description = elements[1];
                        ErrorList.Add(error);
                    }
                }
                //Debug.Print("hello");
            }

            catch (FileNotFoundException exception)
            {
                MessageBox.Show(exception.FileName + "未找到");
                // tabMain.SelectedTab = tpMain;
                //throw;
            }
        }
       

        private void FrmCustomError_Load(object sender, EventArgs e)
        {
            try
            {
                
                //using (StreamReader sr = new StreamReader("CustomError.txt"))
                //{
                //    string line;
                //    while ((line = sr.ReadLine()) != null)
                //    {
                //        string[] elements = line.Split(',');
                //        dgvErrors.Rows.Add(elements);
                //    }
                //}
            }
            catch (FileNotFoundException exception)
            {
                MessageBox.Show(exception.FileName + "未找到");
                // tabMain.SelectedTab = tpMain;
                //throw;
            }
        }

        public void ReportErrors(List<string> ErrorToUpdate,ref System.Windows.Forms.DataGridView dgv)
        {
            foreach (var item in ErrorToUpdate)
            {
               Error error=new Error();
               error.ID = item;
               error.ErrorTime = System.DateTime.Now;
               error.Description = ErrorList.Find((Error err) =>
               {
                   return err.ID == item;
               }).Description;
               Errors.Add(error);
               //dgv.Rows.Add(error.toArray4());
            }

           ErrorHandle.UpdateErrorLog(Errors,ref dgv);
           Errors.Clear();
        }
        private void btnSaveErrorTable_Click(object sender, EventArgs e)
        {
            try
            {

                StreamWriter sw = new StreamWriter("CustomError.txt");
                for (int i = 0; i < dgvErrors.Rows.Count ; i++)
                {
                    sw.WriteLine(this.dgvErrors.Rows[i].Cells[0].Value.ToString() + "," + this.dgvErrors.Rows[i].Cells[1].Value.ToString());
                }
                sw.Close();
                InitErrorList();
                
            }
            catch (FileNotFoundException exception)
            {
                MessageBox.Show(exception.FileName + "未找到");
                // tabMain.SelectedTab = tpMain;
                //throw;
            }
        }

    }
}
