﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace fxplc_comm
{
    public partial class LED1 : Button
    {
        public LED1()
        {
            InitializeComponent();
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            base.OnPaint(pe);
        }
        public bool Status
        {
            get
            {
                if (BackColor==Color.Green)
                {
                    return true;
                }
                else  
                {
                    return false;
                }
                
            }

            set
            {
                if (value==true)
                {
                            
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
