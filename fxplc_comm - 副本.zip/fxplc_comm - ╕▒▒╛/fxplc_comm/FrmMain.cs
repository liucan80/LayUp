﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Resources;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace fxplc_comm
{

    public partial class MainForm : Form
    {
        ResourceManager res_man;
        CultureInfo cul;
        int output000, output001, output002, output003, output004, output005, output006, output007, output010, output011, output012, output013, output014, output015, output016, output017;
        int input000, input001, input002, input003, input004, input005, input006, input007, input010, input011, input012, input013, input014, input015, input016, input017, input024;
        int m8000, m0080,m0231,m0232,m0233,m0234,m0235,m0020,m0081,m0051,m0052,m0053,m0054,m0055,m0056;
        byte[] M128toM143 = new byte[16];
        byte[] LastM128toM143 = new byte[16];
        int d200, d201, d202,d210,d211,d212;
        int stationNumber;
        int M128Status;
        bool connectionStatus = false;
        string port;
        System.Configuration.Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
        FrmCustomError FrmCustomError1;
      
        public MainForm()
        {
           
            try
            {
                InitializeComponent();
                FrmCustomError1 = new FrmCustomError();
                ErrorHandle.Init(ref this.dataGridView2);
                
            }
            catch (Exception e)
            {
                
                MessageBox.Show(e.Message);
            
            }
            
        }
        
        enum errorNames
        {
            初始化,
            正在运行,
            流水线进玻璃超时,
            进铺设位超时
        }
        private void btnConnectPLC_Click(object sender, EventArgs e)
        {
            if (connectionStatus ==false)
            {
                
                if (int.TryParse(txtPLCStationNumber.Text,out stationNumber))
                {
               
                axActUtlType1.ActLogicalStationNumber = stationNumber;
                }
                else
                {
                    errorProvider1.SetError(this.txtPLCStationNumber, "站号输入错误");
                
                    return;
                }
               
                int iReturnCOde = axActUtlType1.Open();
                if (iReturnCOde == 0)
                {
                    toolStripStatusLabel2.Text = "PLC已连接";

                }
                else
                {
                    toolStripStatusLabel2.Text = "PLC连接失败";
                    return;
                }
                connectionStatus = true;
                int cpuType;
                string cpuName;
                int returnCode = axActUtlType1.GetCpuType(out cpuName, out cpuType);
                txtPLCType.Text = cpuName;
                timer1.Start();
                btnWriteIn.Enabled = true;
                tabMain.Enabled = true;
                btnStartTopProgram.Enabled = true;
                btnSwitchStatus.Enabled = true;
                getSetStatus("D200", txtD200);
                getSetStatus("D201", txtD201);
                getSetStatus("D202", txtD202);
                getSetStatus("D210", txtD210);
                getSetStatus("D211", txtD211);
                getSetStatus("D212", txtD212);
                btnConnectPLC.Text = "断开";
               
              

            }
            else
            {
                int iReturnCOde= axActUtlType1.Close();
                btnConnectPLC.Text = "连接";
                if (iReturnCOde == 0)
                {
                    toolStripStatusLabel2.Text = "PLC已断开";
                    btnWriteIn.Enabled = false;

                }
                connectionStatus = false;
            }
            
        }



        private void btnStartStopProgram_Click(object sender, EventArgs e)
        {
            ///设置M81继电器状态,切换PLC程序运行状态，通过获取M20继电器状态，获取PLC程序运行状态。
            ///
            //cusSetStatus(m0020,"m0081");
             axActUtlType1.SetDevice("m0081", 1);
            Thread thr = new Thread(() =>
            {
                //这里还可以处理些比较耗时的事情。
                Thread.Sleep(500);//休眠时间
                int tempReturnCode = axActUtlType1.SetDevice("m0081", 0);
                //this.Dispatcher.Invoke(new Action(() =>
                //{
                //    DoSomeThing();//调用处理事件
                //}));
            });
            thr.Start();
            
           
            
          

        }

        private void tmrGetSetStatus_Tick(object sender, EventArgs e)
        {
           
            
            getSetStatus("x12", btnX012, out input012);
            getSetStatus("x13", btnX013, out input013);
            getSetStatus("x10", btnX010, out input010);
            getSetStatus("x11", btnX011, out input011);
            getSetStatus("x24", btnX024, out input024);
            getSetStatus("x002", btnX002, out input002);
            getSetStatus("x003", btnX003, out input003);
            getSetStatus("x004", btnX004, out input004);
            getSetStatus("x005", btnX005, out input005);
            getSetStatus("x006", btnX006, out input006);
            getSetStatus("x007", btnX007, out input007);
            getSetStatus("x014", btnX014, out input014);
            getSetStatus("x015", btnX015, out input015);
            getSetStatus("y000", btnY000, out output000);
            getSetStatus("y001", btnY001, out output001);
            getSetStatus("y002", btnY002, out output002);
            getSetStatus("y003", btnY003, out output003);
            getSetStatus("y004", btnY004, out output004);
            getSetStatus("y005", btnY005, out output005);
            getSetStatus("y006", btnY006, out output006);
            getSetStatus("y007", btnY007, out output007);
            getSetStatus("y010", btnY010, out output010);
            getSetStatus("y011", btnY011, out output011);
            getSetStatus("y012", btnY012, out output012);
            getSetStatus("y013", btnY013, out output013);
            getSetStatus("y014", btnY014, out output014);
            getSetStatus("y015", btnY015, out output015);
            getSetStatus("y016", btnY016, out output016);
            getSetStatus("y017", btnY017, out output017);
            getSetStatus("m080", btnSwitchStatus, out m0080);
            getSetStatus("m020", btnStartTopProgram, out m0020);
            getSetStatus("m0231", btnM0231, out m0231);
            getSetStatus("m0232", btnM0232, out m0232);
            getSetStatus("m0233", btnM0233, out m0233);
            getSetStatus("m0234", btnM0234, out m0234);
            getSetStatus("m0235", btnM0235, out m0235);
            //读取M128到M143的值
            axActUtlType1.ReadDeviceBlock("M128",1,out M128Status );
            if (true)
            {
                 handleError(M128Status);
            }
            axActUtlType1.GetDevice("m081", out m0081);
            ovalShapeY005.BackColor = btnY005.BackColor;
            ovalShapeY004.BackColor = btnY004.BackColor;
            ovalShapeY012.BackColor = btnY012.BackColor;
            axActUtlType1.GetDevice("M8000", out m8000);
            if (m8000==0)
            {
                toolStripStatusLabel2.Text = "PLC已停止运行";
            }
            else if (m8000==1)
            {
                toolStripStatusLabel2.Text = "PLC正在运行";
            }


        }


        private void btnWriteIn_Click(object sender, EventArgs e)
        {
            try
            {
                string s = Interaction.InputBox("请输入密码", "密码", "", -1, -1);
                // MessageBox.Show(s);
                if (s == "6666")
                {
                    //axActUtlType1.SetDevice("D10",Convert.ToInt32( textBox3.Text));
                    if (int.TryParse(txtD200.Text, out d200))
                    {
                        axActUtlType1.SetDevice("D200", d200);
                       
                    }
                    else
                    {
                        errorProvider1.SetError(txtD200, "请输入正确格式");
                    }
                    if (int.TryParse(txtD201.Text, out d201))
                    {
                        axActUtlType1.SetDevice("D201", d201);
                    }
                    if (int.TryParse(txtD202.Text, out d202))
                    {
                        axActUtlType1.SetDevice("D202", d202);
                    }
                    if (int.TryParse(txtD210.Text, out d210))
                    {
                        axActUtlType1.SetDevice("D210", d210);
                    }
                    if (int.TryParse(txtD211.Text, out d211))
                    {
                        axActUtlType1.SetDevice("D211", d211);
                    }
                    if (int.TryParse(txtD212.Text, out d212))
                    {
                        axActUtlType1.SetDevice("D212", d212);
                    }
                    getSetStatus("D200", txtD200);
                    getSetStatus("D201", txtD201);
                    getSetStatus("D202", txtD202);
                    getSetStatus("D210",txtD210);
                    getSetStatus("D211", txtD211);
                    getSetStatus("D212",txtD212);
                    toolStripStatusLabel1.Text = "写入成功";
                }
                else
                {
                    MessageBox.Show("密码错误");
                }
                
                
            }
            catch (Exception)
            {
                MessageBox.Show("写入D失败");
                
            }
        }
        private int getSetStatus(string name, Button buttonName,out int tempVar)
        {
            int tempInt;
            axActUtlType1.GetDevice(name, out tempInt);
            if (tempInt == 1)
            {
                
                 buttonName.BackColor = Color.Lime;
                 tempVar = 1;

            }
            else
            {
                buttonName.BackColor = Color.Wheat;
                tempVar = 0;
            }
            return 0;
        }
        private int getSetStatus(string name,TextBox textboxName)
        {
            try
            {
                int tempInt;
                axActUtlType1.GetDevice(name, out tempInt);
                textboxName.Text = tempInt.ToString();
                return 0;
            }
            catch (Exception)
            {
                MessageBox.Show("读取"+name+"失败");
                throw;
            }
            
        }
        private void btnY000_Click(object sender, EventArgs e)
        {
            try
            {
                if (output000==1)
                {
                    axActUtlType1.SetDevice("M40", 0);

                }
                else if (output000==0)
                {
                    axActUtlType1.SetDevice("M40", 1);
                }
                
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
        }
        private int cusSetStatus(int deviceNum, string deviceName)
        {
            ///自定义函数，改变PLC软原件状态
            try
            {
                 if (deviceNum==1)
                {
                    axActUtlType1.SetDevice(deviceName, 0);

                }
                else if (deviceNum==0)
                {
                    axActUtlType1.SetDevice(deviceName, 1);
                }
            }
            catch (Exception)
            {
                
                throw;
            }
            return 0;
        }

        private void btnY001_Click(object sender, EventArgs e)
        {
            cusSetStatus(output001, "M41");
        }

        private void btnY002_Click(object sender, EventArgs e)
        {
            cusSetStatus(output002, "M42");
        }

        private void btnY004_Click(object sender, EventArgs e)
        {
            cusSetStatus(output004, "M44");
        }

        private void btnY005_Click(object sender, EventArgs e)
        {
            cusSetStatus(output005, "M45");
        }

        private void btnY007_Click(object sender, EventArgs e)
        {
            cusSetStatus(output007, "M46");
        }

        private void btnY012_Click(object sender, EventArgs e)
        {
            cusSetStatus(output012, "M49");
        }

        

        private void btnSwitchStatus_Click(object sender, EventArgs e)
        {
            //切换手动自动
            cusSetStatus(m0080, "M80");
        }

     
        

        private void tpSecond_Enter(object sender, EventArgs e)
        {
        ///进入IO表界面需要输入密码，密码是6666
        ///
            string s=Interaction.InputBox("请输入密码","密码","",-1,-1);
           // MessageBox.Show(s);
            if (s=="6666")

            {
                tabMain.SelectedTab = tpSecond;
                try
                {
                    using (StreamReader sr = new StreamReader("IO.txt"))
                    {
                        string line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            string[] elements = line.Split(',');
                            dataGridView1.Rows.Add(elements);
                        }
                    }
                }
                catch (FileNotFoundException exception)
                {
                    MessageBox.Show(exception.FileName+"未找到");
                    tabMain.SelectedTab = tpMain;
                    //throw;
                }
                
               

            }
            else
            {
                tabMain.SelectedTab = tpMain;
            }
        }

      

        private void tpMain_Enter(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.Rows.Clear();
            }
            catch (Exception)
            {

                throw;
            }
        }
       

       /// <summary>
        /// 切换语言函数
       /// </summary>
       /// <param name="iLanguage"></param>
 
        void SwitchLanguage(string iLanguage)
        {
            //切换语言
            try
            {
                cul = CultureInfo.CreateSpecificCulture(iLanguage);

                this.Text = res_man.GetString("MainForm_text", cul);
                tpMain.Text = res_man.GetString("MainPage_text", cul);
                tpSecond.Text = res_man.GetString("SecondPage_text", cul);
                btnConnectPLC.Text = res_man.GetString("btnConnect_text", cul);
                grpPLCInfo.Text = res_man.GetString("grpPLCInfo_text", cul);
                lblPLCStationNumber.Text = res_man.GetString("lblPLCStationNumber", cul);
                lblPLCType.Text = res_man.GetString("lblPLCType", cul);
                btnStartTopProgram.Text = res_man.GetString("StartStopProgram_text", cul);
                tabThird.Text = res_man.GetString("ThirdPage_text", cul);
                btnSwitchStatus.Text = res_man.GetString("ManualOrAuto", cul);
            }
            catch (Exception e)
            {

                MessageBox.Show(e.Message);
            }
            
        }

   

        

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
                port = ConfigurationManager.AppSettings["connectPort"];
                btnY000.Text = ConfigurationManager.AppSettings["y000Name"];
                btnY001.Text = ConfigurationManager.AppSettings["y001Name"];
                btnY002.Text = ConfigurationManager.AppSettings["y002Name"];
                btnY003.Text = ConfigurationManager.AppSettings["y003Name"];
                btnY004.Text = ConfigurationManager.AppSettings["y004Name"];
                btnY005.Text = ConfigurationManager.AppSettings["y005Name"];
                btnY005.Text = ConfigurationManager.AppSettings["y005Name"];
                btnY006.Text = ConfigurationManager.AppSettings["y006Name"];
                btnY007.Text = ConfigurationManager.AppSettings["y007Name"];
                btnY010.Text = ConfigurationManager.AppSettings["y010Name"];
                btnY011.Text = ConfigurationManager.AppSettings["y011Name"];
                btnY012.Text = ConfigurationManager.AppSettings["y012Name"];
                btnY013.Text = ConfigurationManager.AppSettings["y013Name"];
                btnY014.Text = ConfigurationManager.AppSettings["y014Name"];
                btnY015.Text = ConfigurationManager.AppSettings["y015Name"];
                btnY016.Text = ConfigurationManager.AppSettings["y016Name"];
                btnY017.Text = ConfigurationManager.AppSettings["y017Name"];

                btnX002.Text = ConfigurationManager.AppSettings["x002Name"];
                btnX003.Text = ConfigurationManager.AppSettings["x003Name"];
                btnX004.Text = ConfigurationManager.AppSettings["x004Name"];
                btnX005.Text = ConfigurationManager.AppSettings["x005Name"];
                btnX006.Text = ConfigurationManager.AppSettings["x006Name"];
                btnX007.Text = ConfigurationManager.AppSettings["x007Name"];
                btnX014.Text = ConfigurationManager.AppSettings["x014Name"];
                btnX015.Text = ConfigurationManager.AppSettings["x015Name"];

                lblD210.Text = ConfigurationManager.AppSettings["D210Name"];
                lblD211.Text=ConfigurationManager.AppSettings["D211Name"];
                lblD212.Text=ConfigurationManager.AppSettings["D212Name"];


                btnM0231.Text=ConfigurationManager.AppSettings["m0231Name"];
                btnM0232.Text = ConfigurationManager.AppSettings["m0232Name"];
                btnM0233.Text = ConfigurationManager.AppSettings["m0233Name"];
                btnM0234.Text = ConfigurationManager.AppSettings["m0234Name"];
                btnM0235.Text = ConfigurationManager.AppSettings["m0235Name"];
 
                //btnY001.Text = ConfigurationManager.AppSettings["y001Name"];
                //btnY001.Text = ConfigurationManager.AppSettings["y001Name"];
                //btnY001.Text = ConfigurationManager.AppSettings["y001Name"];
                //btnY001.Text = ConfigurationManager.AppSettings["y001Name"];
                //btnY001.Text = ConfigurationManager.AppSettings["y001Name"];
                //btnY001.Text = ConfigurationManager.AppSettings["y001Name"];
            }
            catch (Exception)
            {
                Debug.Print("error");
                MessageBox.Show("Test11111111111");
                throw;
            }
        }

        public void modifyControlText(KeyPressEventArgs e ,Button btn,string btnConfigName)
        {
            if (e.KeyChar == 'M')
            {
                string tempString = Interaction.InputBox("请输入按钮文本", "注意!正在修改按钮文本", btn.Text, -1, -1);
                if (tempString.Length>0)
                {
                    config.AppSettings.Settings[btnConfigName].Value =tempString;
                    config.Save(ConfigurationSaveMode.Modified);//保存配置文件
                    ConfigurationManager.RefreshSection("appSettings");//重新加载新的配置文件 
                    btn.Text = ConfigurationManager.AppSettings[btnConfigName];
                }
                //config.AppSettings.Settings[btnConfigName].Value = Interaction.InputBox("请输入按钮文本", "注意!正在修改按钮文本", "", -1, -1);
               
            }
        }
        public void modifyControlText(EventArgs e, Label lbl, string controlConfigName)
        {
            string tempString = Interaction.InputBox("请输入按钮文本", "注意!正在修改按钮文本", "", -1, -1);
            if (tempString.Length > 0)
            {

                config.AppSettings.Settings[controlConfigName].Value = tempString;
                config.Save(ConfigurationSaveMode.Modified);//保存配置文件
                ConfigurationManager.RefreshSection("appSettings");//重新加载新的配置文件 
                lbl.Text = ConfigurationManager.AppSettings[controlConfigName];
            }
        }

        

        private void btnY000_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY000, "y000Name");
        }
        private void btnY001_KeyPress(object sender, KeyPressEventArgs e)
        {

            modifyControlText(e, btnY001, "y001Name");
        }
        private void btnY002_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY002, "y002Name");
        }

        private void btnY004_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY004, "y004Name");
        }

        private void btnY005_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY005, "y005Name");
        }

        private void btnY007_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY007, "y007Name");
        }

        private void btnY012_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY012, "y012Name");
        }

        private void btnY010_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY010, "y010Name");
        }

        private void btnY011_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY011, "y011Name");
        }

        
        private void btnY003_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY003, "y003Name");
        }

        private void btnY003_Click(object sender, EventArgs e)
        {
            cusSetStatus(output003, "M50");
        }

        private void btnY006_Click(object sender, EventArgs e)
        {
            cusSetStatus(output006, "M51");
        }

        private void btnY013_Click(object sender, EventArgs e)
        {
            cusSetStatus(output013, "M52");
        }

        private void btnY014_Click(object sender, EventArgs e)
        {
            cusSetStatus(output014, "M53");
        }

        private void btnY015_Click(object sender, EventArgs e)
        {
            cusSetStatus(output015, "M54");
        }

        private void btnY016_Click(object sender, EventArgs e)
        {
            cusSetStatus(output016, "M55");
        }

        private void btnY017_Click(object sender, EventArgs e)
        {
            cusSetStatus(output017, "M56");
        }

        private void btnY006_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY006, "y006Name");
        }

        private void btnY013_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY013, "y013Name");
        }

        private void btnY014_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY014, "y014Name");
        }

        private void btnY015_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY015, "y015Name");
        }

        private void btnY016_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY016, "y016Name");
        }

        private void btnY017_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnY017, "y017Name");
        }

        private void btnM0231_Click(object sender, EventArgs e)
        {
            cusSetStatus(m0231, "M0231");
        }

        private void btnM0232_Click(object sender, EventArgs e)
        {
            cusSetStatus(m0232, "M0232");

        }

        private void btnM0233_Click(object sender, EventArgs e)
        {
            cusSetStatus(m0233, "M0233");

        }

        private void btnM0234_Click(object sender, EventArgs e)
        {
            cusSetStatus(m0234, "M0234");

        }

        private void btnM0235_Click(object sender, EventArgs e)
        {
            cusSetStatus(m0235, "M0235");

        }

        private void btnM0231_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnM0231, "m0231Name");
        }

        private void btnM0232_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnM0232, "m0232Name");
        }

        private void btnM0233_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnM0233, "m0233Name");

        }

        private void btnM0234_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnM0234, "m0234Name");

        }

        private void btnM0235_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnM0235, "m0235Name");

        }

        private void btnX002_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnX002, "x002Name");
        }

        private void btnX006_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnX006, "x006Name");

        }

        private void btnX007_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnX007, "x007Name");

        }

        private void btnX014_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnX014, "x014Name");

        }

        private void btnX015_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnX015, "x015Name");

        }

        private void btnX003_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnX003, "x003Name");

        }

        private void btnX004_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnX004, "x004Name");

        }

        private void btnX005_KeyPress(object sender, KeyPressEventArgs e)
        {
            modifyControlText(e, btnX005, "x005Name");

        }

        private void lblD210_DoubleClick(object sender, EventArgs e)
        {
            modifyControlText(e, lblD210, "d210Name");

        }

        private void lblD211_DoubleClick(object sender, EventArgs e)
        {
            modifyControlText(e, lblD211, "d211Name");
        }

        private void lblD212_DoubleClick(object sender, EventArgs e)
        {
            modifyControlText(e, lblD212, "d212Name");
        }

        /// <summary>
        /// 最小化时显示到系统任务栏
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void notifyIcon1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (this.WindowState == FormWindowState.Minimized)
                {
                    //还原窗体
                    this.WindowState = FormWindowState.Normal;
                    //系统任务栏显示图标
                    this.ShowInTaskbar = true;
                }
                //激活窗体并获取焦点
                this.Activate();

            }
        }
        /// <summary>
        /// 设置界面为英语
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void englishToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            res_man = new ResourceManager("fxplc_comm.Resource.Res", typeof(MainForm).Assembly);
            SwitchLanguage("en");
        }

        /// <summary>
        /// 设置界面为中文
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void 中文ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            res_man = new ResourceManager("fxplc_comm.Resource.Res", typeof(MainForm).Assembly);
            SwitchLanguage("zh-CHS");

        }

        private void 报警自定义ToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            FrmCustomError1.ShowDialog();
        }

       private void  handleError(int MStatus)
       {
           List<string> ErrorToUpdate = new List<string>();
           if (MStatus != 0)
           {
               toolStripStatusLabel1.Text = "报警发生";
               M128toM143 = CustomMath.ToBinaryBits(M128Status, 16);
               Array.Reverse(M128toM143);
               for (int i = 0; i < M128toM143.Length; i++)
               {
                   if (M128toM143[i] > LastM128toM143[i])
                   {
                       ErrorToUpdate.Add(("M" + ((128 + i).ToString()).ToString()));
                   }
               }
               if (!Enumerable.SequenceEqual(M128toM143,LastM128toM143))
               {
                   FrmCustomError1.ReportErrors(ErrorToUpdate, ref dataGridView2);
                   ErrorToUpdate.Clear();
               }
               LastM128toM143 = (byte[])M128toM143.Clone();
              
           }
           else
           {
               M128toM143 = CustomMath.ToBinaryBits(M128Status, 16);
               Array.Reverse(M128toM143);
               
               LastM128toM143 = (byte[])M128toM143.Clone();
               ErrorToUpdate.Clear();
               toolStripStatusLabel1.Text = " ";
           }
          
          
           //备份当前值，供下次比较使用
          
           //界面报警
           
           //更新数据库
          
           //ErrorHandle1.UpdateErrorLog(ErrorToUpdate);
          // ErrorHandle1.exportToDataView(dataGridView2);

       }

       private void toolStripStatusLabel1_Click(object sender, EventArgs e)
       {
           if (toolStripStatusLabel1.Text!="")
           {
               tabMain.SelectedTab = tabThird;
           }
           
       }

       private void btnClearLog_Click(object sender, EventArgs e)
       {
           ErrorHandle.ClearLog(ref dataGridView2);
       }

       private void btnExportLog_Click(object sender, EventArgs e)
       {
           ErrorHandle.ExportTable();
       }

     

       

       
     
    }
}
